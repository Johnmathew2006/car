import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

// Enum for car types
enum CarType {
    SEDAN,
    TRUCK,
    SUV,
    // Add more as needed
}

// Class representing a vehicle
class Vehicle {
    private String make;
    private String model;
    private String color;
    private CarType type;

    public Vehicle(String make, String model, String color, CarType type) {
        this.make = make;
        this.model = model;
        this.color = color;
        this.type = type;
    }

    // Getters for make and model
    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    // Getters and setters for other fields
    public CarType getType() {
        return type;
    }

    @Override
    public String toString() {
        return make + " " + model + " (" + color + ")";
    }
}

// Class representing an employee
class Employee {
    private String name;

    public Employee(String name) {
        this.name = name;
    }

    // Getter for employee name
    public String getName() {
        return name;
    }
}

// Class representing the dealership
class Dealership {
    private Map<CarType, List<Vehicle>> inventory;
    private List<Employee> employees;

    public Dealership() {
        this.inventory = new HashMap<>();
        for (CarType type : CarType.values()) {
            inventory.put(type, new ArrayList<>());
        }
        this.employees = new ArrayList<>();
    }

    // Method to add an employee
    public void addEmployee(Employee employee) {
        employees.add(employee);
        System.out.println("Employee added: " + employee.getName());
    }

    // Method to add a vehicle to the inventory
    public void addVehicle(Vehicle vehicle, Employee employee) {
        inventory.get(vehicle.getType()).add(vehicle);
        System.out.println("Vehicle added to inventory: " + vehicle);
        System.out.println("Handled by: " + employee.getName());
    }

    // Method to remove a vehicle from the inventory
    public void sellVehicle(Vehicle vehicle, Employee employee) {
        List<Vehicle> vehiclesOfType = inventory.get(vehicle.getType());
        if (vehiclesOfType.contains(vehicle)) {
            vehiclesOfType.remove(vehicle);
            System.out.println("Vehicle sold: " + vehicle);
            System.out.println("Handled by: " + employee.getName());
        } else {
            System.out.println("Error: Vehicle not found in inventory.");
        }
    }

    // Method to buy a vehicle from the inventory
    public Vehicle buyVehicle(CarType type, Employee employee) {
        List<Vehicle> vehiclesOfType = inventory.get(type);
        if (!vehiclesOfType.isEmpty()) {
            Vehicle vehicle = vehiclesOfType.remove(0);
            System.out.println("Vehicle bought from inventory: " + vehicle);
            System.out.println("Handled by: " + employee.getName());
            return vehicle;
        } else {
            System.out.println("Error: No vehicles of type " + type + " available in inventory.");
            return null;
        }
    }

    // Method to display inventory
    public void displayInventory() {
        System.out.println("Inventory:");
        for (CarType type : CarType.values()) {
            System.out.println(type + "s:");
            List<Vehicle> vehiclesOfType = inventory.get(type);
            for (Vehicle vehicle : vehiclesOfType) {
                System.out.println("- " + vehicle);
            }
        }
    }

    // Method to search for vehicles by make and model
    public List<Vehicle> search(String make, String model) {
        List<Vehicle> result = new ArrayList<>();
        for (List<Vehicle> vehiclesOfType : inventory.values()) {
            for (Vehicle vehicle : vehiclesOfType) {
                if (vehicle.getMake().equalsIgnoreCase(make) && vehicle.getModel().equalsIgnoreCase(model)) {
                    result.add(vehicle);
                }
            }
        }
        return result;
    }

    // Other methods to update vehicle details, manage employees, etc.
}

public class Main {
    public static void main(String[] args) {
        Dealership dealership = new Dealership();
        Scanner scanner = new Scanner(System.in);

        // Adding employees
        Employee employee1 = new Employee("Johnny");
        Employee employee2 = new Employee("Janet");
        dealership.addEmployee(employee1);
        dealership.addEmployee(employee2);

        // Adding vehicles
        Vehicle vehicle1 = new Vehicle("Toyota", "Camry", "Blue", CarType.SEDAN);
        Vehicle vehicle2 = new Vehicle("Ford", "F-150", "Black", CarType.TRUCK);
        Vehicle vehicle3 = new Vehicle("Toyota", "Corolla", "Red", CarType.SEDAN);
        dealership.addVehicle(vehicle1, employee1);
        dealership.addVehicle(vehicle2, employee2);
        dealership.addVehicle(vehicle3, employee1);

        while (true) {
            System.out.println("Choose an option:");
            System.out.println("1. Display inventory");
            System.out.println("2. Search for a vehicle");
            System.out.println("3. Buy a vehicle");
            System.out.println("4. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    dealership.displayInventory();
                    break;
                case 2:
                    System.out.println("Enter make of vehicle:");
                    String make = scanner.nextLine();
                    System.out.println("Enter model of vehicle:");
                    String model = scanner.nextLine();
                    List<Vehicle> searchResults = dealership.search(make, model);
                    if (!searchResults.isEmpty()) {
                        System.out.println("Search results:");
                        for (Vehicle vehicle : searchResults) {
                            System.out.println("- " + vehicle);
                        }
                    } else {
                        System.out.println("No vehicles found matching the criteria.");
                    }
                    break;
                case 3:
                    System.out.println("Choose the type of vehicle to buy:");
                    System.out.println("1. Sedan");
                    System.out.println("2. Truck");
                    // Add more options as needed
                    int typeChoice = scanner.nextInt();
                    CarType buyType = null;
                    switch (typeChoice) {
                        case 1:
                            buyType = CarType.SEDAN;
                            break;
                        case 2:
                            buyType = CarType.TRUCK;
                            break;
                        // Add cases for other types
                        default:
                            System.out.println("Invalid choice.");
                    }
                    if (buyType != null) {
                        Vehicle boughtVehicle = dealership.buyVehicle(buyType, employee1); // Change employee as needed
                        if (boughtVehicle != null) {
                            System.out.println("Bought vehicle: " + boughtVehicle);
                        }
                    }
                    break;
                case 4:
                    System.out.println("Exiting program.");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 4.");
            }
        }
    }
}
